# COM-501 Python Assignment
## Digital Photography Shoot and Memory Storage Manager

This repository contains one progressively developed console application for the five COM-501 milestones.

### Project files

- `q1.py` — Q1: single-shoot storage estimate, types, operators and string slicing.
- `q2.py` — Q2: multiple sessions, dictionary, list, set, validation, classification and sorting.
- `q3.py` — Q3: `MemoryCard` and `PhotoSession` classes using composition.
- `photo_utils.py` — reusable functions and user-defined module for Q4/Q5.
- `main.py` — integrated final application for Q4 and Q5.
- `photo_logs/shoot_log.txt` — sample text log; the final program also creates the directory and appends records automatically.

### Requirements

- Python 3.8 or later
- No third-party packages are required.

### Run the milestones

Open a terminal in this project folder and run:

```bash
python q1.py
python q2.py
python q3.py
```

Run the final integrated application with:

```bash
python main.py
```

The final application accepts Portrait, Event, Landscape, Product and Sports sessions. Enter `DONE` at the shoot-type prompt to finish. Accepted sessions are appended to `photo_logs/shoot_log.txt`.

### Storage convention

The application uses 1 GB = 1024 MB. Storage is calculated as:

`photo_count * average_image_size_mb / 1024`

### Before submission

1. Run each milestone yourself and capture your own terminal screenshots.
2. Check the output and log file on your computer.
3. Replace this README's submission details if your instructor requires them.
4. Add your own GitHub repository URL to your PDF report.
5. Use your own roll number in the required PDF and ZIP filenames.

This is a student project template. Review the code, understand it, and follow your institute's rules for individual work.
