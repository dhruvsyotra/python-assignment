# COM-501 | Q4 and Q5: Final Digital Photography Shoot and Memory Storage Manager
import os
import time

from photo_utils import (
    calculate_storage,
    cards_required,
    backup_storage,
    calculate_weekly_summary,
    total_storage
)


class MemoryCard:
    def __init__(self, card_id, capacity_gb):
        if capacity_gb <= 0:
            raise ValueError("Card capacity must be positive.")
        self.card_id = card_id
        self.capacity_gb = capacity_gb
        self.used_gb = 0.0

    def available_space(self):
        return self.capacity_gb - self.used_gb

    def can_store(self, required_gb):
        return required_gb <= self.available_space()

    def store(self, required_gb):
        if not self.can_store(required_gb):
            return False
        self.used_gb += required_gb
        return True


class PhotoSession:
    def __init__(
        self, session_id, photographer_name, shoot_type,
        photo_count, average_size_mb, memory_card, duration_minutes
    ):
        self.session_id = session_id
        self.photographer_name = photographer_name
        self.shoot_type = shoot_type
        self.photo_count = photo_count
        self.average_size_mb = average_size_mb
        self.memory_card = memory_card
        self.duration_minutes = duration_minutes

    def storage_required(self):
        return calculate_storage(self.photo_count, self.average_size_mb)

    def fits_on_assigned_card(self):
        return self.memory_card.can_store(self.storage_required())

    def session_summary(self):
        print(f"\n{self}")
        print("Photos:", self.photo_count)
        print("Storage required (GB):", round(self.storage_required(), 2))
        print("Assigned card:", self.memory_card.card_id)
        print("Card capacity (GB):", self.memory_card.capacity_gb)
        print("Fits on assigned card:", self.fits_on_assigned_card())

    def __str__(self):
        return (
            f"{self.session_id}: {self.shoot_type} shoot by "
            f"{self.photographer_name}"
        )


SHOOT_TYPES = {
    "Portrait": "POR",
    "Event": "EVT",
    "Landscape": "LND",
    "Product": "PRD",
    "Sports": "SPT"
}

LOG_DIRECTORY = "photo_logs"
LOG_FILE = os.path.join(LOG_DIRECTORY, "shoot_log.txt")


def save_session(session):
    """Append one completed session to the text log."""
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(
            f"{session.session_id}|{session.photographer_name}|"
            f"{session.shoot_type}|{session.photo_count}|"
            f"{session.average_size_mb}|{session.memory_card.capacity_gb}|"
            f"{session.duration_minutes}\n"
        )


def read_saved_sessions():
    """Read records, count valid lines, and skip malformed records safely."""
    valid_count = 0
    print("\n===== SAVED SHOOT RECORDS =====")

    try:
        with open(LOG_FILE, "r", encoding="utf-8") as log:
            for line_number, line in enumerate(log, start=1):
                try:
                    fields = line.strip().split("|")
                    if len(fields) != 7:
                        raise ValueError("Record must contain seven fields.")

                    session_id, photographer, shoot_type = fields[:3]
                    photo_count = int(fields[3])
                    average_size = float(fields[4])
                    capacity = float(fields[5])
                    duration = int(fields[6])

                    if (
                        not session_id or not photographer
                        or shoot_type not in SHOOT_TYPES
                        or photo_count <= 0 or average_size <= 0
                        or capacity <= 0 or duration <= 0
                    ):
                        raise ValueError("Record contains invalid values.")

                    print(
                        f"{session_id} | {photographer} | {shoot_type} | "
                        f"{photo_count} photos | {average_size} MB/photo | "
                        f"{capacity} GB card | {duration} minutes"
                    )
                    valid_count += 1

                except (ValueError, IndexError):
                    print(f"Malformed record on line {line_number} skipped.")

    except FileNotFoundError:
        print("Log file not found. No saved records are available.")

    print("Valid stored sessions:", valid_count)

    try:
        print("Log-file size:", os.path.getsize(LOG_FILE), "bytes")
    except FileNotFoundError:
        print("Log-file size unavailable because the file does not exist.")


def get_positive_int(prompt):
    value = int(input(prompt))
    if value <= 0:
        raise ValueError("Value must be a positive whole number.")
    return value


def get_positive_float(prompt):
    value = float(input(prompt))
    if value <= 0:
        raise ValueError("Value must be a positive number.")
    return value


def main():
    start_time = time.time()
    sessions = []
    unique_types = set()

    print("==============================================")
    print(" DIGITAL PHOTOGRAPHY SHOOT AND MEMORY MANAGER")
    print("==============================================")
    print("Shoot types:", ", ".join(SHOOT_TYPES))
    print("Enter DONE as the shoot type to finish.")

    while True:
        shoot_type = input("\nShoot type: ").strip().title()
        if shoot_type == "Done":
            break

        if shoot_type not in SHOOT_TYPES:
            print("Unknown shoot type. Please choose a listed type.")
            continue

        try:
            photographer = input("Photographer name: ").strip()
            if not photographer:
                raise ValueError("Photographer name cannot be empty.")

            photo_count = get_positive_int("Number of photos: ")
            average_size = get_positive_float("Average image size (MB): ")
            capacity = get_positive_float("Memory-card capacity (GB): ")
            duration = get_positive_int("Session duration (minutes): ")

            session_number = len(sessions) + 1
            card = MemoryCard(f"CARD{session_number:03d}", capacity)
            session = PhotoSession(
                f"SES{session_number:03d}", photographer, shoot_type,
                photo_count, average_size, card, duration
            )

            required_gb = session.storage_required()
            if not session.fits_on_assigned_card():
                print(
                    f"Session needs {required_gb:.2f} GB, but the card "
                    f"capacity is {capacity:.2f} GB. Session was not saved."
                )
                continue

            card.store(required_gb)
            sessions.append(session)
            unique_types.add(shoot_type)
            save_session(session)
            print("Session saved successfully.")
            print("Storage required:", round(required_gb, 2), "GB")

        except ValueError as error:
            print("Invalid input:", error)
            print("Please enter the session details again.")

    # Sort this run's sessions by storage, highest first.
    sessions.sort(key=lambda item: item.storage_required(), reverse=True)

    total_photos, total_gb = calculate_weekly_summary(sessions)

    print("\n===== WEEKLY SHOOT SUMMARY =====")
    print("Total sessions this run:", len(sessions))
    print("Total photos:", total_photos)
    print("Total storage (GB):", round(total_gb, 2))
    print("Unique shoot types:", ", ".join(sorted(unique_types)) or "None")
    print("16 GB cards required:", cards_required(total_gb, card_capacity_gb=16))
    print("Backup storage for 2 copies (GB):", round(backup_storage(total_gb, copies=2), 2))
    print("Variable-argument example (GB):", total_storage(2.5, 3.5, 4.0))

    print("\n===== SESSION DETAILS (HIGHEST STORAGE FIRST) =====")
    for session in sessions:
        session.session_summary()

    read_saved_sessions()

    elapsed = time.time() - start_time
    print("\nReport generation time:", round(elapsed, 4), "seconds")
    print("Application completed.")


if __name__ == "__main__":
    main()
