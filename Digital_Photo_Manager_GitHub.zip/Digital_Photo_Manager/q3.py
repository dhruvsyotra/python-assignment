# COM-501 | Q3: OOP and Composition

class MemoryCard:
    def __init__(self, card_id, capacity_gb):
        if capacity_gb <= 0:
            raise ValueError("Card capacity must be positive.")
        self.card_id = card_id
        self.capacity_gb = capacity_gb
        self.used_gb = 0.0

    def available_space(self):
        return self.capacity_gb - self.used_gb

    def can_store(self, required_gb):
        return required_gb <= self.available_space()

    def store(self, required_gb):
        if not self.can_store(required_gb):
            return False
        self.used_gb += required_gb
        return True


class PhotoSession:
    def __init__(
        self, session_id, photographer_name, shoot_type,
        photo_count, average_size_mb, memory_card
    ):
        if photo_count <= 0 or average_size_mb <= 0:
            raise ValueError("Photo count and image size must be positive.")

        self.session_id = session_id
        self.photographer_name = photographer_name
        self.shoot_type = shoot_type
        self.photo_count = photo_count
        self.average_size_mb = average_size_mb
        self.memory_card = memory_card

    def storage_required(self):
        return self.photo_count * self.average_size_mb / 1024

    def fits_on_assigned_card(self):
        return self.memory_card.can_store(self.storage_required())

    def session_summary(self):
        print("\nSession ID:", self.session_id)
        print("Photographer:", self.photographer_name)
        print("Shoot type:", self.shoot_type)
        print("Photos:", self.photo_count)
        print("Storage required (GB):", round(self.storage_required(), 2))
        print("Memory card:", self.memory_card.card_id)
        print("Card capacity (GB):", self.memory_card.capacity_gb)
        print("Card available space (GB):",
              round(self.memory_card.available_space(), 2))
        print("Fits on assigned card:", self.fits_on_assigned_card())

    def __str__(self):
        return f"{self.session_id}: {self.shoot_type} shoot by {self.photographer_name}"


if __name__ == "__main__":
    # Each PhotoSession contains a MemoryCard object: this is composition.
    card1 = MemoryCard("CARD101", 16)
    card2 = MemoryCard("CARD102", 8)

    session1 = PhotoSession("SES001", "Aditi", "Portrait", 320, 18.5, card1)
    session2 = PhotoSession("SES002", "Rahul", "Event", 500, 20, card2)

    print("===== OOP PHOTOGRAPHY SESSION MANAGER =====")
    session1.session_summary()
    session2.session_summary()
    print("\nSession descriptions:")
    print(session1)
    print(session2)
