# COM-501 | Q4/Q5: Reusable functions for photo storage
import math


def calculate_storage(photo_count, avg_size_mb):
    """Return storage required in GB (1 GB = 1024 MB)."""
    return photo_count * avg_size_mb / 1024


def cards_required(storage_gb, card_capacity_gb=16):
    """Return the number of whole cards needed for the storage amount."""
    if storage_gb < 0 or card_capacity_gb <= 0:
        raise ValueError("Storage cannot be negative and card capacity must be positive.")
    return math.ceil(storage_gb / card_capacity_gb)


def backup_storage(storage_gb, copies=2):
    """Return total backup storage for the requested number of copies."""
    if storage_gb < 0 or copies < 0:
        raise ValueError("Storage and number of copies cannot be negative.")
    return storage_gb * copies


def calculate_weekly_summary(sessions):
    """Accept PhotoSession objects; return total photos and total storage in GB."""
    total_photos = sum(session.photo_count for session in sessions)
    total_gb = sum(session.storage_required() for session in sessions)
    return total_photos, total_gb


def total_storage(*session_sizes):
    """Demonstrate a variable number of storage-size arguments."""
    return sum(session_sizes)
