# COM-501 | Q2: Manage Multiple Photography Sessions

shoot_types = {
    "Portrait": "POR",
    "Event": "EVT",
    "Landscape": "LND",
    "Product": "PRD",
    "Sports": "SPT"
}

sessions = []
unique_shoot_types = set()

print("===== WEEKLY PHOTOGRAPHY SESSION MANAGER =====")
print("Valid shoot types:", ", ".join(shoot_types))
print("Enter DONE when all sessions have been entered.")

while True:
    shoot_type = input("\nShoot type: ").strip().title()

    if shoot_type == "Done":
        break

    if shoot_type not in shoot_types:
        print("Invalid shoot type. Choose one of the listed types.")
        continue

    try:
        photo_count = int(input("Number of photos: "))
        average_size_mb = float(input("Average image size (MB): "))
    except ValueError:
        print("Invalid numeric input. Please try this session again.")
        continue

    if photo_count <= 0 or average_size_mb <= 0:
        print("Photo count and image size must both be positive.")
        continue

    storage_gb = photo_count * average_size_mb / 1024

    if storage_gb < 4:
        category = "Light"
    elif storage_gb <= 8:
        category = "Moderate"
    else:
        category = "Heavy"

    sessions.append({
        "shoot_type": shoot_type,
        "photo_count": photo_count,
        "average_size_mb": average_size_mb,
        "storage_gb": storage_gb,
        "category": category
    })
    unique_shoot_types.add(shoot_type)
    print("Session added successfully.")

sessions.sort(key=lambda item: item["storage_gb"], reverse=True)

total_photos = sum(item["photo_count"] for item in sessions)
total_storage_gb = sum(item["storage_gb"] for item in sessions)

print("\n===== WEEKLY SHOOT SUMMARY =====")
print("Total sessions:", len(sessions))
print("Total photos:", total_photos)
print("Total storage (GB):", round(total_storage_gb, 2))
print("Unique shoot types:", ", ".join(sorted(unique_shoot_types)) or "None")

print("\nSessions from highest to lowest storage:")
for item in sessions:
    print(
        f'{item["shoot_type"]}: {item["photo_count"]} photos, '
        f'{item["storage_gb"]:.2f} GB, {item["category"]}'
    )
