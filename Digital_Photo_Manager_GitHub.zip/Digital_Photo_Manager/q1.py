# COM-501 | Q1: Estimate Storage for One Photo Shoot

photographer_name = input("Enter photographer name: ").strip()
shoot_type = input("Enter shoot type: ").strip()
photo_count = int(input("Enter number of photos: "))
average_size_mb = float(input("Enter average image size (MB): "))
card_capacity_gb = float(input("Enter memory-card capacity (GB): "))
duration_minutes = int(input("Enter session duration (minutes): "))

print("\n--- Data Types ---")
print("Photo count type:", type(photo_count))
print("Average image size type:", type(average_size_mb))

total_storage_mb = photo_count * average_size_mb
total_storage_gb = total_storage_mb / 1024
remaining_space_gb = card_capacity_gb - total_storage_gb

hours = duration_minutes // 60
minutes = duration_minutes % 60

name_code = photographer_name[:3].upper()
type_code = shoot_type[:3].upper()
session_code = name_code + "-" + type_code

print("\n===== SHOOT STORAGE REPORT =====")
print("Photographer:", photographer_name)
print("Shoot type:", shoot_type)
print("Session code:", session_code)
print("Total photos:", photo_count)
print("Total storage (MB):", round(total_storage_mb, 2))
print("Total storage (GB):", round(total_storage_gb, 2))
print("Memory-card capacity (GB):", card_capacity_gb)
print("Remaining card space (GB):", round(remaining_space_gb, 2))
print(f"Duration: {hours} hours and {minutes} minutes")

if remaining_space_gb < 0:
    print("Warning: The shoot exceeds the memory-card capacity.")
